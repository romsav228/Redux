export const selectNotesLoading = state => state.notes.loading
export const selectNotesError = state => state.notes.error
export const selectNotesData = state => state.notes.data